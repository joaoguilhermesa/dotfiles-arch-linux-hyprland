<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='epp.package.jee' timestamp='1741254166341'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/jenkins/agent/workspace/epp_master/packages/org.eclipse.epp.package.jee.product/target/products/epp.package.jee/linux/gtk/x86_64/eclipse'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/jenkins/agent/workspace/epp_master/packages/org.eclipse.epp.package.jee.product/target/products/epp.package.jee/linux/gtk/x86_64/eclipse'/>
  </properties>
</profile>
